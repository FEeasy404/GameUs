import React from "react";
import EmailPasswordForm from "../components/organisms/EmailPasswordForm/EmailPasswordForm";

function JoinPage() {
  return <EmailPasswordForm title="이메일로 회원 가입" label="다음" />;
}

export default JoinPage;
