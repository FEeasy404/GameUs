import React from "react";
import ProfileSetting from "../components/organisms/ProfileSetting/ProfileSetting";

function ProfileSettingPage() {
  return (
    <>
      <ProfileSetting />
    </>
  );
}

export default ProfileSettingPage;
